package com.cg.updatestatusbe.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Product {
	
		@Id
		@Column(name="product_id")
		private int id;
		
		@Column(name="product_name")
		private String name;
		
		@Column(name="ordered_date")
		private String orderedDate;

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getOrderedDate() {
			return orderedDate;
		}

		public void setOrderedDate(String orderedDate) {
			this.orderedDate = orderedDate;
		}

		public Product(int id, String name, String orderedDate) {
			super();
			this.id = id;
			this.name = name;
			this.orderedDate = orderedDate;
		}
		
		public Product() {
			
		}
}
