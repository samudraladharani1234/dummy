package com.cg.updatestatusbe.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.updatestatusbe.bean.Product;
import com.cg.updatestatusbe.repo.IStatusBeRepo;

@Service
public class StatusBeServiceImpl implements IStatusBeService{

	@Autowired
	IStatusBeRepo repo;
	
	@Override
	public Optional<Product> getProductById(int id) {	
		return repo.findById(id);
		
	}

	
}
