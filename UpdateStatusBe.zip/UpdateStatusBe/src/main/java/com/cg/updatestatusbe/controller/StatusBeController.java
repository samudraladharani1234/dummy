package com.cg.updatestatusbe.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.updatestatusbe.bean.Product;
import com.cg.updatestatusbe.service.IStatusBeService;

@RestController
public class StatusBeController {

	@Autowired
	IStatusBeService service;
	
	@RequestMapping("/getProducts/{id}")
	public Optional<Product> getProductById(@PathVariable int id){
		return service.getProductById(id); 
		
	}
}
