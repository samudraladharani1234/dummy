package com.cg.updatestatusbe.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.updatestatusbe.bean.Product;

@Repository
public interface IStatusBeRepo extends CrudRepository<Product, Integer>{

}
