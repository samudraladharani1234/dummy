package com.cg.updatestatusbe.service;

import java.util.Optional;

import com.cg.updatestatusbe.bean.Product;

public interface IStatusBeService {
	
	public Optional<Product> getProductById(int id);

}
