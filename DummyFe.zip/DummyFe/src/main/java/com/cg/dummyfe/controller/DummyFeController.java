package com.cg.dummyfe.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.cg.dummyfe.bean.Product;

@RestController
public class DummyFeController {

	@RequestMapping("/homepro")
	public ModelAndView home() {
		RestTemplate rt=new RestTemplate();
		Product p=rt.getForObject("http://localhost:7373/getProducts/1001", Product.class);
		ModelAndView mv=new ModelAndView();
		mv.addObject("obj",p);
		mv.setViewName("OrderPlaced");
		return mv;	
	}
	 
	@RequestMapping("/Packed")
	public ModelAndView packedProduct() {
		RestTemplate rt=new RestTemplate();
		Product p=rt.getForObject("http://localhost:7373/getProducts/1001", Product.class);
		ModelAndView mv=new ModelAndView();
		mv.addObject("obj",p);
		mv.setViewName("Packed");
		return mv;	
	}
	
	@RequestMapping("/InProcess")
	public ModelAndView inProcessProduct(){
		RestTemplate rt=new RestTemplate();
		Product p=rt.getForObject("http://localhost:7373/getProducts/1001", Product.class);
		ModelAndView mv=new ModelAndView();
		mv.addObject("obj",p);
		mv.setViewName("InProcess");
		return mv;
	}
	
	@RequestMapping("/OutFordelivery")
	public ModelAndView outForDelieveryProduct() {
		RestTemplate rt=new RestTemplate();
		Product p=rt.getForObject("http://localhost:7373/getProducts/1001", Product.class);
		ModelAndView mv=new ModelAndView();
		mv.addObject("obj",p);
		mv.setViewName("OutFordelivery");
		return mv;	
	}
	
	@RequestMapping("/Delivered")
	public ModelAndView deliveredProduct() {
		RestTemplate rt=new RestTemplate();
		Product p=rt.getForObject("http://localhost:7373/getProducts/1001", Product.class);
		ModelAndView mv=new ModelAndView();
		mv.addObject("obj",p);
		mv.setViewName("Delivered");
		return mv;	
	}
	
}
