package com.cg.dummyfe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages="com.cg.dummyfe")
public class DummyFeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DummyFeApplication.class, args);
	}
}
