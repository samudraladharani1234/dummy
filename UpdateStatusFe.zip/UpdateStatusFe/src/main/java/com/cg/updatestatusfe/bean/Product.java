package com.cg.updatestatusfe.bean;

public class Product {

	private int id;
	private String name;
	private String orderedDate;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOrderedDate() {
		return orderedDate;
	}
	public void setOrderedDate(String orderedDate) {
		this.orderedDate = orderedDate;
	}
	public Product(int id, String name, String orderedDate) {
		super();
		this.id = id;
		this.name = name;
		this.orderedDate = orderedDate;
	}
	
	public Product() {
		
	}
}
