package com.cg.updatestatusfe.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.cg.updatestatusfe.bean.Product;


@RestController
public class StatusFeController {

	@RequestMapping("/homepro")
	public ModelAndView home() {
		RestTemplate rt=new RestTemplate();
		Product p=rt.getForObject("http://localhost:9898/getProducts/1001", Product.class);
		return new ModelAndView("OrderPlaced","cust",p);	
	}
	 
	@RequestMapping("/Packed")
	public ModelAndView packedProduct() {
		RestTemplate rt=new RestTemplate();
		Product p=rt.getForObject("http://localhost:9898/getProducts/1001", Product.class);
		return new ModelAndView("Packed","cust",p);
	}
	
	@RequestMapping("/InProcess")
	public ModelAndView inProcessProduct(){
		RestTemplate rt=new RestTemplate();
		Product p=rt.getForObject("http://localhost:9898/getProducts/1001", Product.class);
		return new ModelAndView("InProcess","cust",p);
	}
	
	@RequestMapping("/OutFordelivery")
	public ModelAndView outForDelieveryProduct() {
		RestTemplate rt=new RestTemplate();
		Product p=rt.getForObject("http://localhost:9898/getProducts/1001", Product.class);
		return new ModelAndView("OutFordelivery","cust",p);	
	}
	
	@RequestMapping("/Delivered")
	public ModelAndView deliveredProduct() {
		RestTemplate rt=new RestTemplate();
		Product p=rt.getForObject("http://localhost:9898/getProducts/1001", Product.class);
		return new ModelAndView("Delivered","cust",p);	
	}
	
}
