package com.cg.updatestatusfe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages="com.cg.updatestatusfe")
public class UpdateStatusFeApplication {

	public static void main(String[] args) {
		SpringApplication.run(UpdateStatusFeApplication.class, args);
	}
}
