package com.cg.dummy.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.dummy.bean.Product;

public interface IDummyRepo extends CrudRepository<Product, Integer>{

}
