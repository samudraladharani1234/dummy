package com.cg.dummy.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dummy.bean.Product;
import com.cg.dummy.service.IDummyService;

@RestController
public class DummyController {

	@Autowired
	IDummyService service;
	
	@RequestMapping("/getProducts/{id}")
	public Optional<Product> getProductById(@PathVariable int id){
		return service.getProductById(id); 
		
	}
}
 