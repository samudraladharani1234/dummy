package com.cg.dummy.service;

import java.util.Optional;

import com.cg.dummy.bean.Product;

public interface IDummyService {

	public Optional<Product> getProductById(int id);
	
}
