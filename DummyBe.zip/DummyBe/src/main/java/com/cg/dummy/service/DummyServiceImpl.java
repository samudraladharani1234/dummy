package com.cg.dummy.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dummy.bean.Product;
import com.cg.dummy.repo.IDummyRepo;

@Service
public class DummyServiceImpl implements IDummyService{
	
	@Autowired
	IDummyRepo repo;

	@Override
	public Optional<Product> getProductById(int id) {	
		return repo.findById(id);
	}

	
}
