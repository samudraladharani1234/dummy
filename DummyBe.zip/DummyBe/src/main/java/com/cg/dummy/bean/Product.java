package com.cg.dummy.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Product {

	@Id
	@Column(name="product_id")
	private int id;
	
	@Column(name="product_name")
	private String name;

	@Column(name="product_image")
	private String image;
	
	@Column(name="ordered_date")
	private String orderedDate;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getOrderedDate() {
		return orderedDate;
	}

	public void setOrderedDate(String orderedDate) {
		this.orderedDate = orderedDate;
	}

	public Product(int id, String name, String image, String orderedDate) {
		super();
		this.id = id;
		this.name = name;
		this.image = image;
		this.orderedDate = orderedDate;
	}
	
	public Product() {
		
	}
	
	

}
