package com.cg.demo.service;

import java.math.BigDecimal;
import java.util.HashMap;

import com.cg.demo.beans.Customer;
import com.cg.demo.beans.Wallet;
import com.cg.demo.repo.WalletRepo;
import com.cg.demo.repo.WalletRepoImpl;

public class WalletServiceImpl implements WalletService{
	
	private WalletRepo repo;

	public WalletServiceImpl() {
		repo = new WalletRepoImpl();
	}

	@Override
	public Customer createAccount(String name, String mobileNo, BigDecimal amount) {
		Wallet wallet = new Wallet();
		Customer customer = new Customer();
	
		wallet.setBalance(amount);
		customer.setName(name);
		customer.setMobileNo(mobileNo);
		customer.setWallet(wallet);
	
		repo.save(customer);

		return customer;

	}

	@Override
	public Customer showBalance(String mobileNo) {
		Customer customer=repo.findOne(mobileNo);
		if(customer!=null)	
		return customer;
		return customer;
	}

	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {
		Customer customer = withdrawAmount(sourceMobileNo, amount);
		depositAmount(targetMobileNo, amount);
		return customer;
		
	}

	@Override
	public Customer depositAmount(String mobileno, BigDecimal amount) {
		Customer customer = repo.findOne(mobileno);
		Wallet wallet = customer.getWallet();
		wallet.setBalance(wallet.getBalance().add(amount));
	
		//repo.remove(mobileno);
	
		if(repo.save(customer)) {
			return customer;
		
	}
		return customer;
	}
	public Customer withdrawAmount(String mobileNo, BigDecimal amount) {
		
			Customer customer = repo.findOne(mobileNo);
			Wallet wallet = customer.getWallet();
			wallet.setBalance(wallet.getBalance().subtract(amount));
		
		
			if(repo.save(customer)) {
				return customer;
			}
			return null;
	}
}
	

	

	