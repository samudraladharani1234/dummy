package com.cg.demo.repo;

import java.util.HashMap;
import java.util.Map;

import com.cg.demo.beans.Customer;

public class WalletRepoImpl implements WalletRepo{

	private Map<String, Customer> data; 

	public WalletRepoImpl() 
	{
		data = new HashMap<String, Customer>();
	}
	@Override
	public boolean save(Customer customer) {
		
		if(data.get(customer.getMobileNo()) == null) {
			data.put(customer.getMobileNo(), customer);
			return true;
		}
		return false;
	}

	@Override
	public Customer findOne(String mobileNo) {
		
		if(data.get(mobileNo) != null) {
			return data.get(mobileNo);
		}
		return null;
	}

}

