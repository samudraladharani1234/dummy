package com.cg.updatestatusbe.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.updatestatusbe.bean.Inventory;

@Repository
public interface IInventoryRepo extends CrudRepository<Inventory, Integer> {

}
