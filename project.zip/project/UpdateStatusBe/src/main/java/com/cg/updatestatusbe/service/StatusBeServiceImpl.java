package com.cg.updatestatusbe.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.updatestatusbe.bean.Inventory;
import com.cg.updatestatusbe.bean.OrderTable;
import com.cg.updatestatusbe.repo.IInventoryRepo;
import com.cg.updatestatusbe.repo.IOrderRepo;

@Service
public class StatusBeServiceImpl implements IStatusBeService {

	@Autowired
	IOrderRepo order;

	@Override
	public OrderTable getProductById(int id) {
		return order.findById(id).get();
	}

	@Override
	public List<Integer> getOrderById(String customerId) {
		List<OrderTable> orders = new ArrayList<>();
		List<Integer> list = new ArrayList<>();

		order.findAll().forEach(orders::add);
		for (OrderTable orderTable : orders) {
			if (orderTable.getCustomerId().equals(customerId)) {
				list.add(orderTable.getOrderId());
			}
		}
		return list;
	}

	@Autowired
	IInventoryRepo repo;

	@Override
	public List<Inventory> showAllProducts() {
		List<Inventory> list = new ArrayList<>();
		repo.findAll().forEach(list::add);
		return list;
	}

	@Override
	public boolean showStatus(int productId) {
		Inventory inventory = repo.findById(productId).get();
		if (inventory.getProduct_count() > 0) {
			inventory.setProduct_count(inventory.getProduct_count() - 1);
			repo.save(inventory);
			return true;
		} else {
			return false;
		}
	}
}
