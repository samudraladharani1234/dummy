package com.cg.updatestatusbe.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class OrderTable {
	@Id
	private int orderId;
	private String customerId;
	private int productId;
	private String orderDate;

	public OrderTable() {
		// TODO Auto-generated constructor stub
	}

	public OrderTable(int orderId, String customerId, int productId, String orderDate) {
		super();
		this.orderId = orderId;
		this.customerId = customerId;
		this.productId = productId;
		this.orderDate = orderDate;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

}