package com.cg.updatestatusbe.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.updatestatusbe.bean.Inventory;
import com.cg.updatestatusbe.bean.OrderTable;
import com.cg.updatestatusbe.service.IStatusBeService;

@RestController
public class StatusBeController {

	@Autowired
	IStatusBeService service;

	@RequestMapping("/getProducts{id}")
	public OrderTable getProductById(@RequestParam int id) {
		return service.getProductById(id);

	}
	
	@RequestMapping("/getOrders{customerId}")
	public List<Integer> getOrderById(@RequestParam String customerId){
		return service.getOrderById(customerId);
	}
	
	@RequestMapping("/buy{id}")
	public boolean showStatus(@RequestParam int id) {
		return service.showStatus(id);
	}
	
	@RequestMapping("/inventory")
	public List<Inventory> showInventory(){
		List<Inventory> list=service.showAllProducts();
		return list;
	}
}
