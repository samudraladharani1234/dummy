package com.cg.updatestatusbe.service;

import java.util.List;

import com.cg.updatestatusbe.bean.Inventory;
import com.cg.updatestatusbe.bean.OrderTable;

public interface IStatusBeService {
	
	public OrderTable getProductById(int id);

	public List<Integer> getOrderById(String customerId);

	public boolean showStatus(int id);

	public List<Inventory> showAllProducts();

}
