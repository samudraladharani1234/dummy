package com.cg.updatestatusbe.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.updatestatusbe.bean.OrderTable;

@Repository
public interface IOrderRepo extends CrudRepository<OrderTable, Integer>{

}
