package com.cg.updatestatusfe.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class JspController {

	@RequestMapping(value = "/")
	public String sayHello() {
		return "index";
	}

	@RequestMapping(value = "/status")
	public String status() {
		return "status";
	}
}
