package com.cg.updatestatusfe.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.cg.updatestatusfe.bean.Inventory;
import com.cg.updatestatusfe.bean.Order;

@RestController
public class StatusFeController {

	@RequestMapping("/homepro{id}")
	public ModelAndView home(@RequestParam String id) {
		RestTemplate rt = new RestTemplate();
		Order p = rt.getForObject("http://localhost:9898/getProducts?id=" + id, Order.class);
		return new ModelAndView("OrderPlaced", "cust", p);
	}

	@RequestMapping("/Packed{id}")
	public ModelAndView packed(@RequestParam String id) {
		RestTemplate rt = new RestTemplate();
		Order p = rt.getForObject("http://localhost:9898/getProducts?id=" + id, Order.class);

		return new ModelAndView("Packed", "cust", p);
	}

	@RequestMapping("/InProcess{id}")
	public ModelAndView process(@RequestParam String id) {
		RestTemplate rt = new RestTemplate();
		Order p = rt.getForObject("http://localhost:9898/getProducts?id=" + id, Order.class);
		return new ModelAndView("InProcess", "cust", p);
	}

	@RequestMapping("/OutFordelivery{id}")
	public ModelAndView outForDelivery(@RequestParam String id) {
		RestTemplate rt = new RestTemplate();
		Order p = rt.getForObject("http://localhost:9898/getProducts?id=" + id, Order.class);
		return new ModelAndView("OutFordelivery", "cust", p);
	}

	@RequestMapping("/Delivered{id}")
	public ModelAndView delivered(@RequestParam String id) {
		RestTemplate rt = new RestTemplate();
		Order p = rt.getForObject("http://localhost:9898/getProducts?id=" + id, Order.class);

		return new ModelAndView("Delivered", "cust", p);
	}

	@RequestMapping("/orders{customerId}")
	public ModelAndView getOrders(@RequestParam String customerId) {
		RestTemplate restTemplate = new RestTemplate();
		List<Integer> list = restTemplate.getForObject("http://localhost:9898/getOrders?customerId=" + customerId,
				ArrayList.class);
		return new ModelAndView("orders", "list", list);
	}

	@RequestMapping("/buy{id}")
	public ModelAndView showStatus(@RequestParam String id) {
		RestTemplate template = new RestTemplate();
		boolean result = template.getForObject("http://localhost:9898/buy?id=" + id, Boolean.class);
		if (result) {
			return new ModelAndView("success");
		} else {
			return new ModelAndView("Error");
		}

	}

	@RequestMapping("/inventory")
	public ModelAndView showInventory() {
		RestTemplate template = new RestTemplate();
		List<Inventory> list = template.getForObject("http://localhost:9898/inventory", ArrayList.class);
		return new ModelAndView("display", "list", list);
	}
}
