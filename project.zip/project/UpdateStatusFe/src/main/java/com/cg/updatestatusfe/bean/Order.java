package com.cg.updatestatusfe.bean;

public class Order {

	private String customerId;
	private int orderId;
	private String orderDate;
	private int productId;

	public Order() {
	}

	
	public Order(String customerId, int orderId, String orderDate, int productId) {
		super();
		this.customerId = customerId;
		this.orderId = orderId;
		this.orderDate = orderDate;
		this.productId = productId;
	}


	public String getCustomerId() {
		return customerId;
	}


	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}


	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

}
