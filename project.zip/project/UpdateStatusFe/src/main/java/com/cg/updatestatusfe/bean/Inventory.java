package com.cg.updatestatusfe.bean;

public class Inventory {

	
	private String merchant_Email;
	private String product_name;
	
	private int product_id;
	private Integer product_count;
	
	public Inventory() {
	}
	
	public String getMerchant_Email() {
		return merchant_Email;
	}
	public void setMerchant_Email(String merchant_Email) {
		this.merchant_Email = merchant_Email;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public Integer getProduct_count() {
		return product_count;
	}
	public void setProduct_count(Integer product_count) {
		this.product_count = product_count;
	}
	
	public Inventory(String merchant_Email, String product_name, int product_id, Integer product_count) {
		super();
		this.merchant_Email = merchant_Email;
		this.product_name = product_name;
		this.product_id = product_id;
		this.product_count = product_count;
	}

	
}
