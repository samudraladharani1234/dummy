package com.cg.paymentwallet.Exception;

public interface IWalletException {
String ERROR1="Invalid name";
String ERROR2="Invalid phone number";
String ERROR3="Invalid email id";
String ERROR4="Account already exists";
String ERROR5="Incorrect user Id or password! ";
String ERROR6="Sorry! Couldn't transfer amount to the desired user Id!";
}
